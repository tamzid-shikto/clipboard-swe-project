const fs = require("fs");
const path = require("path");

const db_file_name = "database.json";
const db_path = path.join(__dirname, db_file_name);

DB = {};

async function Init(){
    if(!fs.existsSync(db_path)){
        fs.writeFileSync(db_path, "{}");
    }
    DB = JSON.parse(fs.readFileSync(db_path).toString());
}

async function SaveDBState(){
    fs.writeFileSync(db_path, JSON.stringify(DB));
}

async function Get(bucket_name, key, default_value){
    return DB[bucket_name][key] | default_value;
}
async function Save(bucket_name, key, value){
    DB[bucket_name][key] = value;
    await SaveDBState();
}

exports.Init = Init;
exports.Get = Get;
exports.Save = Save;